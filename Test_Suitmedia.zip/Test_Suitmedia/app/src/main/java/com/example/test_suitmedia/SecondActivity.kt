package com.example.test_suitmedia

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class SecondActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_second)

        val userNameInput = intent.getStringExtra("userName1")
        val userNameList = intent.getStringExtra("userName")

        val welcomeText: TextView = findViewById(R.id.welcomeText)
        val userNameInputLabel: TextView = findViewById(R.id.userName1Label)
        val chooseUserButton: Button = findViewById(R.id.chooseUserButton)
        val userNameLabel: TextView = findViewById(R.id.userNameLabel)

        welcomeText.text = getString(R.string.welcome)
        userNameInputLabel.text = userNameInput
        userNameLabel.text = userNameList ?: getString(R.string.default_user_name)

        chooseUserButton.setOnClickListener {
            goToThirdActivity(userNameInput)
        }
    }

    private fun goToThirdActivity(userNameInput: String?) {
        val intent = Intent(this, ThirdActivity::class.java)
        intent.putExtra("userName1", userNameInput)
        startActivity(intent)
    }
}
