package com.example.test_suitmedia

import android.annotation.SuppressLint
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import androidx.appcompat.app.AlertDialog

class MainActivity : AppCompatActivity() {

    private lateinit var nameInput: EditText
    private lateinit var sentenceInput: EditText

    private var userName1: String = ""

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        nameInput = findViewById(R.id.nameInput)
        sentenceInput = findViewById(R.id.sentenceInput)

        val checkButton: Button = findViewById(R.id.checkButton)
        val nextButton: Button = findViewById(R.id.nextButton)

        checkButton.setOnClickListener {
            checkPalindrome()
        }

        nextButton.setOnClickListener {
            goToSecondScreen()
        }
    }

    private fun checkPalindrome() {
        val name = nameInput.text.toString()
        val sentence = sentenceInput.text.toString()

        val isPalindrome = isPalindrome(sentence)

        val message = if (isPalindrome) "isPalindrome" else "not palindrome"

        AlertDialog.Builder(this)
            .setMessage(message)
            .setPositiveButton("OK", null)
            .show()
    }

    private fun isPalindrome(s: String): Boolean {
        val cleanString = s.replace("\\s+".toRegex(), "").toLowerCase()
        val reversedString = cleanString.reversed()
        return cleanString == reversedString
    }

    private fun showDialog(message: String) {
        AlertDialog.Builder(this)
            .setMessage(message)
            .setPositiveButton("OK") { _, _ -> }
            .show()
    }
    private fun goToSecondScreen() {
        val intent = Intent(this, SecondActivity::class.java)
        intent.putExtra("userName1", nameInput.text.toString())
        startActivityForResult(intent, 1)
    }

}
