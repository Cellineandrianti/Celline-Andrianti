package com.example.test_suitmedia

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import com.example.test_suitmedia.api.ApiService
import com.example.test_suitmedia.model.User
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

class ThirdActivity : AppCompatActivity() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var swipeRefreshLayout: SwipeRefreshLayout

    private val users: MutableList<User> = mutableListOf()
    private var page = 1
    private val perPage = 10
    private lateinit var adapter: UserAdapter

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_third)

        recyclerView = findViewById(R.id.recyclerView)
        swipeRefreshLayout = findViewById(R.id.swipeRefreshLayout)

        adapter = UserAdapter(users)

        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.adapter = adapter

        swipeRefreshLayout.setOnRefreshListener {
            page = 1
            getUsers()
        }

        adapter.setOnItemClickListener(object : UserAdapter.OnItemClickListener {
            override fun onItemClick(user: User) {
                val fullName = "${user.first_name} ${user.last_name}"
                val userNameInput = intent.getStringExtra("userName1")

                val intent = Intent(this@ThirdActivity, SecondActivity::class.java)

                intent.putExtra("userName", fullName)
                intent.putExtra("userName1", userNameInput)

                startActivity(intent)
            }
        })

        getUsers()
    }

    private fun getUsers() {
        val loggingInterceptor = HttpLoggingInterceptor().apply {
            level = HttpLoggingInterceptor.Level.BODY
        }

        val client = OkHttpClient.Builder()
            .addInterceptor(loggingInterceptor)
            .build()

        val retrofit = Retrofit.Builder()
            .baseUrl("https://reqres.in/api/")
            .addConverterFactory(GsonConverterFactory.create())
            .client(client)
            .build()

        val apiService = retrofit.create(ApiService::class.java)
        val call = apiService.getApiResponse(page, perPage)

        call.enqueue(object : Callback<ApiResponse> {
            override fun onResponse(call: Call<ApiResponse>, response: Response<ApiResponse>) {
                if (response.isSuccessful) {
                    val apiResponse = response.body()
                    if (page == 1) {
                        users.clear()
                    }
                    apiResponse?.data?.let { users.addAll(it) }
                    adapter.notifyDataSetChanged()
                } else {
                    Toast.makeText(this@ThirdActivity, "Failed to get users", Toast.LENGTH_SHORT).show()
                }

                swipeRefreshLayout.isRefreshing = false
            }

            override fun onFailure(call: Call<ApiResponse>, t: Throwable) {
                Log.e("ThirdActivity", "Failed to get users", t)
                Toast.makeText(this@ThirdActivity, "Failed to get users: ${t.message}", Toast.LENGTH_SHORT).show()
                swipeRefreshLayout.isRefreshing = false
            }
        })

    }
}
