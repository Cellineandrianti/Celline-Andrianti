package com.example.test_suitmedia.api

import com.example.test_suitmedia.ApiResponse
import com.example.test_suitmedia.model.User
import retrofit2.Call
import retrofit2.http.GET
import retrofit2.http.Query
interface ApiService {
    @GET("users")
    fun getApiResponse(@Query("page") page: Int, @Query("per_page") perPage: Int): Call<ApiResponse>
}
